#!/bin/bash
set -e -u -x -o pipefail

docker-compose down --volumes
